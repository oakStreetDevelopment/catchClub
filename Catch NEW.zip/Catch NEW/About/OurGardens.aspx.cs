﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Mail;

public partial class About_OurGardens : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Submit_Click(object sender, ImageClickEventArgs e)
    {
 

    const string SERVER = "relay-hosting.secureserver.net";
    MailMessage oMail = new System.Web.Mail.MailMessage();
    oMail.From = "GardenTourRequest@catchwaterside.com";
    oMail.To = "Aaron.Berger@marriott.com";
    oMail.Subject = "Garden Tour Request";
    oMail.BodyFormat = MailFormat.Html; // enumeration
    oMail.Priority = MailPriority.High; // enumeration
    oMail.Body = "<b>Sent at:</b> " + DateTime.Now + "</br> <b> First Name: </b>" + First_Name.Text + "</br> <b> Last Name: </b>" + Last_Name.Text + "</br> <b> Email: </b>" + Email.Text + "</br> <b> Telephone: </b>" + Phone.Text + "</br> <b> Group Size: </b>" + Group.Text  ;
    SmtpMail.SmtpServer = SERVER;
    SmtpMail.Send(oMail);
    oMail = null; // free up resources


    Response.Redirect("~/default.aspx");
    



}
    }
